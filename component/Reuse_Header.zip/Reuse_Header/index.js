import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native'
import React from 'react'
import { Colors } from '../../Theme'
import { useNavigation } from '@react-navigation/native'
import { Fav } from '../../Theme/Images'

const Reuse_Header = (props) => {
    const navigation = useNavigation()
    return (
        <View style={{...styles.header,...props.headerStyle}} >
            <TouchableOpacity onPress={props.onLeft}>
                <Image source={props.leftHeaderIcon} style={{ ...styles.icon, ...props.headerIcon }} />
            </TouchableOpacity>
            <Text style={{ ...styles.title, ...props.TextStyle }}>{props.title}</Text>
            <TouchableOpacity onPress={props.onRight} >
                <Image source={props.rightHeaderIcon} style={{ ...styles.rightIcon, ...props.CustomRightIcon }} />
            </TouchableOpacity>
        </View>
    )
}

export default Reuse_Header

const styles = StyleSheet.create({
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingTop: '6%',
    },
    title: {
        fontSize: 16,
        fontWeight: '600',
        lineHeight: 19,
        color: Colors.black,
    },
    icon: {
        height: 18,
        width: 18
    },
    rightIcon: {
        height: 20,
        width: 20,
        resizeMode:'contain'
    }
})